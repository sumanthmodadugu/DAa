$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("FeaturefilesUC95/UC95_LocationZoneUpdate.feature");
formatter.feature({
  "name": "UC95 Amend Service Yield Management Parameters",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "DSS Import LocationZoneUpdate type. Add a new Location to an existing Super-Zone where the new Location is unique within all Yield Group Mappings.",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@LocationZone"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Logon to NRS and navigate to Maintain Location Zones.",
  "keyword": "Given "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Logon_to_NRS_and_navigate_to_Maintain_Location_Zones()"
});
formatter.result({
  "error_message": "org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d66.0.3359.139)\n  (Driver info: chromedriver\u003d2.36.540470 (e522d04694c7ebea4ba8821272dbef4f9b818c91),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.11.0\u0027, revision: \u0027e59cfb3\u0027, time: \u00272018-03-11T20:26:55.152Z\u0027\nSystem info: host: \u0027LIN17000231\u0027, ip: \u002710.74.151.139\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.36.540470 (e522d04694c7eb..., userDataDir: C:\\Users\\suvbaner\\AppData\\L...}, cssSelectorsEnabled: true, databaseEnabled: false, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 66.0.3359.139, webStorageEnabled: true}\nSession ID: fbdb9680126363fee5573accc19e12dc\n*** Element info: {Using\u003dlink text, value\u003dLogin}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:545)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:319)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByLinkText(RemoteWebDriver.java:373)\r\n\tat org.openqa.selenium.By$ByLinkText.findElement(By.java:246)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:311)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy17.click(Unknown Source)\r\n\tat com.AtocDSS.DSSTestcases.PageFunctions.LoginPageObjects.verifylogin(LoginPageObjects.java:47)\r\n\tat com.AtocDSS.DSSTestcases.UC95.DSS_Import_LocationZoneUpdate_type.Logon_to_NRS_and_navigate_to_Maintain_Location_Zones(DSS_Import_LocationZoneUpdate_type.java:73)\r\n\tat ✽.Logon to NRS and navigate to Maintain Location Zones.(FeaturefilesUC95/UC95_LocationZoneUpdate.feature:4)\r\n",
  "status": "failed"
});
formatter.step({
  "name": "Enquire on Super Zone - Pre-DSS Update.",
  "keyword": "When "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Enquire_on_Super_Zone_Pre_DSS_Update()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "To find last sequence number used",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.To_find_last_sequence_number_used()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Upload the XML file to App server /inbound/dss/in",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Upload_the_XML_file_to_App_server_inbound_dss_in()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Logon to the Tandem Check status of PUB747.",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Logon_to_the_Tandem_Check_status_of_PUB_(int)"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "run runBatchDSSin.sh",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.run_runBatchDSSin_sh()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Check the /inbound/dss/received folder",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Check_the_inbound_dss_received_folder()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Check the file in /outbound/dss/in folder",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Check_the_file_in_outbound_dss_in_folder()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "run runDSSBatch.sh",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.run_runDSSBatch_sh()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Check the file in sent folder",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Check_the_file_in_sent_folder()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Check the logs",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Check_the_logs()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Download the xml file",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Download_the_xml_file()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Validate the file",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Validate_the_file()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Check the file in fax server",
  "keyword": "And "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Check_the_file_in_fax_server()"
});
formatter.result({
  "status": "skipped"
});
formatter.step({
  "name": "Check the UI is updated",
  "keyword": "Then "
});
formatter.match({
  "location": "DSS_Import_LocationZoneUpdate_type.Check_the_UI_is_updated()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});