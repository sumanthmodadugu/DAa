package AtocDSSSOPI;

import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.RetailSopi;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class UC101 {
	
	RetailSopi rs = new RetailSopi();
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	Scenario scenario;
	String feature;
	
	@Before
	public void before(Scenario scenario) {
		 this.scenario = scenario;
		 this.feature=scenario.getId().split(";")[0].toUpperCase();
	   
	   
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/RetailSopi/"+scenario.getName()+".docx");
		
	}

	@Given("^select MessageFile Directory XML_BQ_Availability Request – (\\d+) journey with a single leg, (\\d+) passenger sets$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Request_journey_with_a_single_leg_passenger_sets(int arg1, int arg2) throws Throwable {
	    
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_TogetherAvailabilityRequest();
	}

	@Given("^select required Environment_Availability Request – (\\d+) journey with a single leg, (\\d+) passenger sets$")
	public void select_required_Environment_Availability_Request_journey_with_a_single_leg_passenger_sets(int arg1, int arg2) throws Throwable {
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Availability Request – (\\d+) journey, multiple legs and single passenger set$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Request_journey_multiple_legs_and_single_passenger_set(int arg1) throws Throwable {
	    
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_TogetherAvailabilityRequest();
	}

	@Given("^select required Environment_Availability Request – (\\d+) journey, multiple legs and single passenger set$")
	public void select_required_Environment_Availability_Request_journey_multiple_legs_and_single_passenger_set(int arg1) throws Throwable {
	   
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Availability Request – (\\d+) journey and multiple passenger sets$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Request_journey_and_multiple_passenger_sets(int arg1) throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_TogetherAvailabilityRequest();
	    
	}

	@Given("^select required Environment_Availability Request – (\\d+) journey and multiple passenger sets$")
	public void select_required_Environment_Availability_Request_journey_and_multiple_passenger_sets(int arg1) throws Throwable {
	   
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Availability Request – Too many passengers entered - Error message returned$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Request_Too_many_passengers_entered_Error_message_returned() throws Throwable {
	    
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_TogetherAvailabilityRequest();
	}

	@Given("^select required Environment_Availability Request – Too many passengers entered - Error message returned$")
	public void select_required_Environment_Availability_Request_Too_many_passengers_entered_Error_message_returned() throws Throwable {
	   
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Request – (\\d+) journeys, multiple legs and a single passenger set$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Request_journeys_multiple_legs_and_a_single_passenger_set(int arg1) throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedTogetherAvailabilityRequest(); 
	   
	}

	@Given("^select required Environment_Full Availability Request – (\\d+) journeys, multiple legs and a single passenger set$")
	public void select_required_Environment_Full_Availability_Request_journeys_multiple_legs_and_a_single_passenger_set(int arg1) throws Throwable {
	   
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Request – (\\d+) journey with multiple passenger sets$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Request_journey_with_multiple_passenger_sets(int arg1) throws Throwable {
	  
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedTogetherAvailabilityRequest(); 
	}

	@Given("^select required Environment_Full Availability Request – (\\d+) journey with multiple passenger sets$")
	public void select_required_Environment_Full_Availability_Request_journey_with_multiple_passenger_sets(int arg1) throws Throwable {
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Request – (\\d+) journey, (\\d+) leg and (\\d+) passenger set$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Request_journey_leg_and_passenger_set(int arg1, int arg2, int arg3) throws Throwable {
	  
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedTogetherAvailabilityRequest(); 
	}

	@Given("^select required Environment_Full Availability Request – (\\d+) journey, (\\d+) leg and (\\d+) passenger set$")
	public void select_required_Environment_Full_Availability_Request_journey_leg_and_passenger_set(int arg1, int arg2, int arg3) throws Throwable {
		rs.chooseEnv();
	    
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Request – (\\d+) journey, (\\d+) leg, single passenger set with less than (\\d+) passengers – Availability should be displayed$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Request_journey_leg_single_passenger_set_with_less_than_passengers_Availability_should_be_displayed(int arg1, int arg2, int arg3) throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedTogetherAvailabilityRequest(); 
	}

	@Given("^select required Environment_Full Availability Request – (\\d+) journey, (\\d+) leg, single passenger set with less than (\\d+) passengers – Availability should be displayed$")
	public void select_required_Environment_Full_Availability_Request_journey_leg_single_passenger_set_with_less_than_passengers_Availability_should_be_displayed(int arg1, int arg2, int arg3) throws Throwable {
		rs.chooseEnv();
	    
	}
/* ----------------------------------- UC101 DO AVAILABILITY ENQUIRY BERTHS  ----------------------------------------------*/

	@Given("^select MessageFile Directory XML_BQ_Availability Multiple Products Request – (\\d+) journey with a single leg$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Multiple_Products_Request_journey_with_a_single_leg(int arg1) throws Throwable {
	   
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_AvaliblityRequest(); 
	}

	@Given("^select required Environment_Availability Multiple Products Request – (\\d+) journey with a single leg$")
	public void select_required_Environment_Availability_Multiple_Products_Request_journey_with_a_single_leg(int arg1) throws Throwable {
		rs.chooseEnv();
	    
	}

	@Given("^select MessageFile Directory XML_BQ_Availability Multiple Products Request – (\\d+) journey, single leg and passenger set with multiple ticket types$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Multiple_Products_Request_journey_single_leg_and_passenger_set_with_multiple_ticket_types(int arg1) throws Throwable {
	   
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_AvaliblityRequest(); 
	}

	@Given("^select required Environment_Availability Multiple Products Request – (\\d+) journey, single leg and passenger set with multiple ticket types$")
	public void select_required_Environment_Availability_Multiple_Products_Request_journey_single_leg_and_passenger_set_with_multiple_ticket_types(int arg1) throws Throwable {
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Availability Multiple Products Request – Too many passengers are entered error message is returned$")
	public void select_MessageFile_Directory_XML_BQ_Availability_Multiple_Products_Request_Too_many_passengers_are_entered_error_message_is_returned() throws Throwable {
	   
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_AvaliblityRequest();
	}

	@Given("^select required Environment_Availability Multiple Products Request – Too many passengers are entered error message is returned$")
	public void select_required_Environment_Availability_Multiple_Products_Request_Too_many_passengers_are_entered_error_message_is_returned() throws Throwable {
		rs.chooseEnv();
	    
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Multiple Products Request – (\\d+) journeys, single leg, PAX with Multiple ticket types$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Multiple_Products_Request_journeys_single_leg_PAX_with_Multiple_ticket_types(int arg1) throws Throwable {
	   
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedAvailabilityRequest(); 
	}

	@Given("^select required Environment_Full Availability Multiple Products Request – (\\d+) journeys, single leg, PAX with Multiple ticket types$")
	public void select_required_Environment_Full_Availability_Multiple_Products_Request_journeys_single_leg_PAX_with_Multiple_ticket_types(int arg1) throws Throwable {
		rs.chooseEnv();
	    
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Multiple Products Request – (\\d+) journey, multiple legs and PAX with multiple ticket types$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Multiple_Products_Request_journey_multiple_legs_and_PAX_with_multiple_ticket_types(int arg1) throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedAvailabilityRequest();
	    
	}

	@Given("^select required Environment_Full Availability Multiple Products Request – (\\d+) journey, multiple legs and PAX with multiple ticket types$")
	public void select_required_Environment_Full_Availability_Multiple_Products_Request_journey_multiple_legs_and_PAX_with_multiple_ticket_types(int arg1) throws Throwable {
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability Multiple Products Request – ReEdit Enquiry - Leg is removed$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Multiple_Products_Request_ReEdit_Enquiry_Leg_is_removed() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedAvailabilityRequest();
	}

	@Given("^select required Environment_Full Availability Multiple Products Request – ReEdit Enquiry - Leg is removed$")
	public void select_required_Environment_Full_Availability_Multiple_Products_Request_ReEdit_Enquiry_Leg_is_removed() throws Throwable {
		rs.chooseEnv();
	}

	@Given("^select MessageFile Directory XML_BQ_Full Availability - Multiple Products – Facility request only$")
	public void select_MessageFile_Directory_XML_BQ_Full_Availability_Multiple_Products_Facility_request_only() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_UnrestrictedAvailabilityRequest();
	}

	@Given("^select required Environment_Full Availability - Multiple Products – Facility request only$")
	public void select_required_Environment_Full_Availability_Multiple_Products_Facility_request_only() throws Throwable {
		rs.chooseEnv();
	}
	
}
