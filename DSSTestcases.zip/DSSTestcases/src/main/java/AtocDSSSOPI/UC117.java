package AtocDSSSOPI;

import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.RetailSopi;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class UC117 {
	RetailSopi rs = new RetailSopi();
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	Scenario scenario;
	String feature;
	
	@Before
	public void before(Scenario scenario) {
		 this.scenario = scenario;
		 this.feature=scenario.getId().split(";")[0].toUpperCase();
	   
	   
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/RetailSopi/"+scenario.getName()+".docx");
		
	}
	
	

@Given("^select MessageFile Directory XML_Make a single Leg Season Ticket Booking for a period of one month$")
public void select_MessageFile_Directory_XML_Make_a_single_Leg_Season_Ticket_Booking_for_a_period_of_one_month() throws Throwable {
	rs.startSOPI();
	rs.xmlChooser();
	rs.select_SeasonBookingRequest();
}

@Given("^select required Environment_Make a single Leg Season Ticket Booking for a period of one month$")
public void select_required_Environment_Make_a_single_Leg_Season_Ticket_Booking_for_a_period_of_one_month() throws Throwable {
	rs.chooseEnv();
}
}
