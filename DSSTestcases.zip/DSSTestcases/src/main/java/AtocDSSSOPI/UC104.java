package AtocDSSSOPI;

import org.apache.commons.net.nntp.NewsgroupInfo;
import org.jaxen.pattern.Pattern;
import org.openqa.selenium.support.PageFactory;

import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.RetailSopi;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class UC104 {
	RetailSopi rs = new RetailSopi();
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	Scenario scenario;
	String feature;
	
	@Before
	public void before(Scenario scenario) {
		 this.scenario = scenario;
		 this.feature=scenario.getId().split(";")[0].toUpperCase();
	   
	   
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/RetailSopi/"+scenario.getName()+".docx");
		
	}
	
	@Given("^select MessageFile Directory XML_BQ$")
	public void select_MessageFile_Directory_XML() throws Throwable {
		
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_BookingRequest();
	
	   
	   
	}



@Given("^select MessageFile Directory XML_Single leg and PAX group reservation$")
public void select_MessageFile_Directory_XML_Single_leg_and_PAX_group_reservation() throws Throwable {
   
	rs.startSOPI();
	rs.xmlChooser();
	rs.select_GroupBookingRequest();
	
	
	

}





}
