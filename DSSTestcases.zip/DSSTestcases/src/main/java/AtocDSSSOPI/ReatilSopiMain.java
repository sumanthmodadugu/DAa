package AtocDSSSOPI;

import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.RetailSopi;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import gherkin.formatter.model.Feature;

public class ReatilSopiMain {
	RetailSopi rs = new RetailSopi();
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	Scenario scenario;
	String feature;
	
	@Before
	public void before(Scenario scenario) {
		 this.scenario = scenario;
		 this.feature=scenario.getId().split(";")[0].toUpperCase();
	   
	   
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/RetailSopi/"+scenario.getName()+".docx");
		
	}
	
	
	@Given("^select required Environment$")
	public void select_required_Environment() throws Throwable {
		rs.chooseEnv();
	}

@Given("^Copy Input XMl$")
public void launchretailsopi_and_Enter_xmlpath() throws Throwable {

rs.putInputXML("./AllTestDataFile/RetailSopiTestData/"+feature+"/"+scenario.getName()+".xml");
}

@And("^copy Resopnse Screenshot$")
public void clik_on_SendMessage() throws Throwable {
    rs.finalOutput("./Screenshots/RetailSopi/"+feature+"/"+scenario.getName()+".png"); 
    ws.insertPic(System.getProperty("user.dir")+"/Screenshots/RetailSopi/"+feature+"/"+scenario.getName()+".png",scenario.getName());
}

}




