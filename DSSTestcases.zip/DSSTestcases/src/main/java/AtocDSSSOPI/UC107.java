package AtocDSSSOPI;

import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.RetailSopi;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class UC107 {

	RetailSopi rs = new RetailSopi();
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	Scenario scenario;
	String feature;
	
	@Before
	public void before(Scenario scenario) {
		 this.scenario = scenario;
		 this.feature=scenario.getId().split(";")[0].toUpperCase();
	   
	   
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/RetailSopi/"+scenario.getName()+".docx");
		
	}
	
	@Given("^select MessageFile Directory XML_Cancel whole seated booking Recall$")
	public void select_MessageFile_Directory_XML_Cancel_whole_seated_booking_Recall() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_RecallBookingRequest();
	}

	@Given("^select MessageFile Directory XML_Cancel whole seated booking Cancel$")
	public void select_MessageFile_Directory_XML_Cancel_whole_seated_booking_Cancel() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_CancelBookingRequest();
	}

	@Given("^select MessageFile Directory XML_Attempt to cancel Group Booking – error message returned$")
	public void select_MessageFile_Directory_XML_Attempt_to_cancel_Group_Booking_error_message_returned() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_CancelBookingRequest();
	}

	@Given("^select MessageFile Directory XML_Cancel whole group booking Recall$")
	public void select_MessageFile_Directory_XML_Cancel_whole_group_booking_Recall() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_RecallBookingRequest();
	}

	@Given("^select MessageFile Directory XML_Cancel whole group booking Cancel$")
	public void select_MessageFile_Directory_XML_Cancel_whole_group_booking_Cancel() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_CancelGroupBookingRequest();
	}

	@Given("^select MessageFile Directory XML_Attempt to cancel non Group Booking – error message returned$")
	public void select_MessageFile_Directory_XML_Attempt_to_cancel_non_Group_Booking_error_message_returned() throws Throwable {
		rs.startSOPI();
		rs.xmlChooser();
		rs.select_CancelGroupBookingRequest();
	}
}
