package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;
import org.sikuli.script.SikuliException;



public class FilecheckfromRemote {

	public  void checkPresent(String Server, String Username, String Password,String Location, String Filename, String Screenshotname) throws IOException, SikuliException, Exception {
		
		App mstsc=App.open("C:\\Windows\\System32\\mstsc.exe");
		Region appregion=mstsc.focusedWindow();
		Screen screen=new Screen();
		Region appRegion=App.focusedWindow();
		Pattern RDComputerfield=new Pattern("D:\\apache\\RDComputerField.PNG");
		Pattern Computer=new Pattern("D:\\apache\\Computer.PNG");
		Pattern connect=new Pattern("D:\\apache\\Connect.PNG");
		Pattern user=new Pattern("D:\\apache\\supervisor.PNG");
		Pattern password=new Pattern("D:\\apache\\Password.PNG");
		Pattern Okbutton=new Pattern("D:\\apache\\Okbutton.PNG");
		Pattern yesbutton=new Pattern("D:\\apache\\Yes.PNG");
		Pattern okbuttonremote=new Pattern("D:\\apache\\Okbuttonremote.PNG");
		Pattern Startbutton=new Pattern("D:\\apache\\Startbutton.PNG");
		Pattern Mycomputer=new Pattern("D:\\apache\\Mycomputer.PNG");
		Pattern ddrive=new Pattern("D:\\apache\\DDrive.PNG");
		Pattern maximize=new Pattern("D:\\apache\\Maximize.PNG");
		Pattern servermanager=new Pattern("D:\\apache\\Servermanagerremote.PNG");
		Pattern servermanagerclose=new Pattern("D:\\apache\\Servermanagerremoteclose.PNG");
		Pattern Searchfile=new Pattern("D:\\apache\\SearchBox.PNG");
		Pattern findfailed=new Pattern("D:\\apache\\FindFailed.PNG");
		Pattern logoff=new Pattern("D:\\apache\\RemoteLogoff.PNG");
		screen.type(RDComputerfield,Key.BACKSPACE);
		screen.type(Computer, Server);
		screen.type(Key.ENTER);
		//screen.click(connect);
		screen.wait(user,10);
		screen.click(user);
		screen.wait(password,10);
		screen.type(password, Password);
		screen.click(Okbutton);
		screen.wait(yesbutton,30);
		screen.click(yesbutton);
		screen.wait(okbuttonremote,40);
		screen.click(okbuttonremote);
		//screen.click(maximize);
		
		
		
		screen.wait(servermanagerclose,40);
		screen.click(servermanagerclose);
		screen.wait(Startbutton,20);
		screen.click(Startbutton);
		screen.type(Searchfile,Location);
		screen.type(Key.ENTER);
		Thread.sleep(3000);
		ImageIO.write(screen.capture(appRegion).getImage(), "png", new File(Screenshotname));
		//screen.type(Key.ENTER);
		screen.click(Startbutton);
		screen.type(Searchfile,Location+Filename);
		screen.type(Key.ENTER);
		if(screen.exists(findfailed)!=null)
			System.out.println("File does not exist");
		else
			System.out.println("File does exist");
		screen.click(Startbutton);
		screen.click(logoff);
		
		
		
		
		
		

	}

}
