package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class WordScreenshot {
	
	public XWPFDocument doc=new XWPFDocument();
	public XWPFParagraph p=doc.createParagraph();
	public XWPFRun r=p.createRun();
	
	public void insertPic(String picloc1, String SetText) throws Exception{
		
		
		
		
		
		File pic1 = new File(picloc1);
		String imgFile1 = pic1.getName();		
		int imgFormat1 = getImageFormat(imgFile1);		
		r.setText(SetText);
		r.addBreak();
		r.addPicture(new FileInputStream(pic1), imgFormat1, imgFile1, Units.toEMU(500), Units.toEMU(300));
		r.addBreak(BreakType.PAGE);
		
		
	}
	
public void inserttext(String text, String SetText) throws Exception{
		
		
		
		
		
				
		r.setText(SetText);
		r.addBreak();
		r.setText(text);
		r.addBreak();
		
		r.addBreak(BreakType.PAGE);
		
		
	}
public void printout(String FileLoc) throws Exception{
		FileOutputStream out = new FileOutputStream(FileLoc);
		doc.write(out);
		out.close();
		doc.close();
		
	}
	
	private static int getImageFormat(String imgFile) {
		int format;
		if (imgFile.endsWith(".emf"))
			format = XWPFDocument.PICTURE_TYPE_EMF;
		else if (imgFile.endsWith(".wmf"))
			format = XWPFDocument.PICTURE_TYPE_WMF;
		else if (imgFile.endsWith(".pict"))
			format = XWPFDocument.PICTURE_TYPE_PICT;
		else if (imgFile.endsWith(".jpeg") || imgFile.endsWith(".jpg"))
			format = XWPFDocument.PICTURE_TYPE_JPEG;
		else if (imgFile.endsWith(".png"))
			format = XWPFDocument.PICTURE_TYPE_PNG;
		else if (imgFile.endsWith(".dib"))
			format = XWPFDocument.PICTURE_TYPE_DIB;
		else if (imgFile.endsWith(".gif"))
			format = XWPFDocument.PICTURE_TYPE_GIF;
		else if (imgFile.endsWith(".tiff"))
			format = XWPFDocument.PICTURE_TYPE_TIFF;
		else if (imgFile.endsWith(".eps"))
			format = XWPFDocument.PICTURE_TYPE_EPS;
		else if (imgFile.endsWith(".bmp"))
			format = XWPFDocument.PICTURE_TYPE_BMP;
		else if (imgFile.endsWith(".wpg"))
			format = XWPFDocument.PICTURE_TYPE_WPG;
		else {
			return 0;
		}
		return format;
	}

	

}
