package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;
import org.sikuli.script.SikuliException;



public class PuttyLaunching  {
    public   App putty;
    public   Screen screen;
    public void puttylaunchingmethod(String host, String user, String Passwd, String location, String command, String screenshotloc) throws Exception{
    	putty=App.open("C:\\Program Files\\PuTTY\\PuTTY.exe");
		screen=new Screen();
		Region appRegion = App.focusedWindow();
		
		Pattern hostname=new Pattern("D:\\apache\\PuttyHostName.PNG");
		Pattern puttyopen=new Pattern("D:\\apache\\PuttyOpen.PNG");
		Pattern puttyusername=new Pattern("D:\\apache\\PuttyUsername.PNG");
		Pattern puttypassword=new Pattern("D:\\apache\\PuttyPassword.PNG");
		Pattern puttystartpoint=new Pattern("D:\\apache\\PuttyStartpoint.PNG");
		Pattern puttyrunjob=new Pattern("D:\\apache\\PuttyRunJob.PNG");
		Pattern puttymaximize=new Pattern("D:\\apache\\PuttyMaximise.PNG");
		Pattern minimize=new Pattern("D:\\apache\\MinimizePutty.PNG");
		screen.type(hostname,host);
		screen.click(puttyopen);
		screen.click(puttymaximize);
		screen.type(puttyusername,user);
		screen.type(Key.ENTER);
		screen.type(puttypassword,Passwd);
		screen.type(Key.ENTER);
		screen.type(puttystartpoint,location);
		screen.type(Key.ENTER);
		screen.type(puttyrunjob,command);
		screen.type(Key.ENTER);
		screen.wait(puttyrunjob,40);
		//screen.type(puttyrunjob,"./runDSSBatch.sh");
		//screen.type(Key.ENTER);
		
        //TakeScreenshot screenshot=new TakeScreenshot(putty,screen);
       // screenshot.screenshot();
		Thread.sleep(5000);
		ImageIO.write(screen.capture(appRegion).getImage(), "png", new File(screenshotloc));
		screen.click(minimize);
	}
    
	
}
