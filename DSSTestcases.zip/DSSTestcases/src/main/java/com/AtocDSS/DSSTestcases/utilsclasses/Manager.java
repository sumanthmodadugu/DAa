package com.AtocDSS.DSSTestcases.utilsclasses;

import com.AtocDSS.DSSTestcases.UC95.ConfigFileReader;

public class Manager {
	private static Manager fileReaderManager = new Manager();
	private static ConfigFileReader configFileReader;

	private Manager() {
	}

	 public static Manager getInstance( ) {
	      return fileReaderManager;
	 }

	 public ConfigFileReader getConfigReader() {
		 return (configFileReader == null) ? new ConfigFileReader() : configFileReader;
	 }

}
