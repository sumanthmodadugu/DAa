package com.AtocDSS.DSSTestcases.utilsclasses;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.AtocDSS.DSSTestcases.PageFunctions.BrowserOperation;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class Takescreenshots extends BrowserOperation {
	public void screenshot(String fileWithPath) throws Exception{
		
	
	Screenshot sc=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(500)).takeScreenshot(driver);
	ImageIO.write(sc.getImage(),"PNG",new File(fileWithPath));
	}

}
