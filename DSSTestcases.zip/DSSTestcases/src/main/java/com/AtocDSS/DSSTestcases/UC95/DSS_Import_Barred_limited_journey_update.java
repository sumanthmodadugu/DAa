package com.AtocDSS.DSSTestcases.UC95;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.AtocDSS.DSSTestcases.PageFunctions.Allocations;
import com.AtocDSS.DSSTestcases.PageFunctions.AssignNestedModeltoRSS;
import com.AtocDSS.DSSTestcases.PageFunctions.BrowserOperation;
import com.AtocDSS.DSSTestcases.PageFunctions.Homepage;
import com.AtocDSS.DSSTestcases.PageFunctions.LoginPageObjects;
import com.AtocDSS.DSSTestcases.PageFunctions.MaintainService;
import com.AtocDSS.DSSTestcases.PageFunctions.MaintainSpecificService;
import com.AtocDSS.DSSTestcases.PageFunctions.ServiceNestedModel;
import com.AtocDSS.DSSTestcases.utilsclasses.FTPDownloader;
import com.AtocDSS.DSSTestcases.utilsclasses.FTPUploader;
import com.AtocDSS.DSSTestcases.utilsclasses.FileValidation;
import com.AtocDSS.DSSTestcases.utilsclasses.FileZilla;
import com.AtocDSS.DSSTestcases.utilsclasses.FilecheckfromRemote;
import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.PuttyLaunching;
import com.AtocDSS.DSSTestcases.utilsclasses.ReadingPropertiesfile;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.Telnetconnection;
import com.AtocDSS.DSSTestcases.utilsclasses.UkTime;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class DSS_Import_Barred_limited_journey_update {
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	WebDriver driver;
	LoginPageObjects login;
	MaintainSpecificService maintainspecificservice;
	MaintainService maintainservice;
	ServiceNestedModel servicenestedmodel;
	AssignNestedModeltoRSS assignnestedmodeltorss;
	Allocations allocation;
	Telnetconnection telnet=new Telnetconnection();
	FTPUploader upld=new FTPUploader();
	FileZilla fz=new FileZilla();
	PuttyLaunching putty=new PuttyLaunching();
	UkTime tm=new UkTime();
	String UKTIME;
	FTPDownloader dn=new FTPDownloader();
	FileValidation fl=new FileValidation();
	FilecheckfromRemote fc=new FilecheckfromRemote();
	String ALLOCATION;
	
	Scenario scenario;
	
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95 DSS_Import_Yield Management Update-allocation limits.docx");
		
	}
	
	@Given("^Logon to NRS and navigate to Maintain Service Barred Limited Journey - Service has no Barred Limited Journeys at present.$")
	public void Logon_to_NRS_and_navigate_to_Maintain_Service_Barred_Limited_Journey_Service_has_no_Barred_Limited_Journeys_at_present() throws Throwable {
		driver=BrowserOperation.launchApplication(ReadingPropertiesfile.readcontent("URL","./AllTestDataFile/"+scenario.getName()+".properties"));
		login=PageFactory.initElements(driver, LoginPageObjects.class);
		login.verifylogin(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties"), ReadingPropertiesfile.readcontent("Password","./AllTestDataFile/"+scenario.getName()+".properties"));
		if(!login.locationPresent(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties")))
				login.selectlocation();
		
		Homepage Home=PageFactory.initElements(driver, Homepage.class);
		maintainspecificservice=Home.navigate_to_maintain_specificservice();
		maintainservice=maintainspecificservice.navigate_to_maintain_service(ReadingPropertiesfile.readcontent("RSID","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FromDate","./AllTestDataFile/"+scenario.getName()+".properties"));
		screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to NRS and navigate to Maintain specific service.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to NRS and navigate to Maintain specific service.png",
				"Logon to NRS and navigate to Maintain specific service." );
	}
	@Then("^Naviagte to MaintainSpecficServices$")
	public void naviagte_to_MaintainSpecficServices() throws Throwable {
			maintainservice=PageFactory.initElements(driver, MaintainService.class);
		    maintainservice.Barred_Limited_Journeys();
		    screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Empty Barred Limited Journeys.png");
			ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Empty Barred Limited Journeys.png",
					"Empty Barred Limited Journeys." );
			driver.close();
		}

	@Then("^Check the UI BLJ is updated$")
	public void Check_the_UI_BLJ_is_updated() throws Throwable {
	    
		driver=BrowserOperation.launchApplication(ReadingPropertiesfile.readcontent("URL","./AllTestDataFile/"+scenario.getName()+".properties"));
		login=PageFactory.initElements(driver, LoginPageObjects.class);
		login.verifylogin(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties"), ReadingPropertiesfile.readcontent("Password","./AllTestDataFile/"+scenario.getName()+".properties"));
		if(!login.locationPresent(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties")))
				login.selectlocation();
		
		Homepage Home=PageFactory.initElements(driver, Homepage.class);
		maintainspecificservice=Home.navigate_to_maintain_specificservice();
		maintainservice=maintainspecificservice.navigate_to_maintain_service(ReadingPropertiesfile.readcontent("RSID","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FromDate","./AllTestDataFile/"+scenario.getName()+".properties"));
		screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to NRS and check for update.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to NRS and check for update.png",
				"Logon to NRS and check for update." );
		maintainservice=PageFactory.initElements(driver, MaintainService.class);
	    maintainservice.Barred_Limited_Journeys();
	    screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/barred limited journey with 1 yield group.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/barred limited journey with 1 yield group.png",
				"barred limited journey with 1 yield group." );
		
	}

}
