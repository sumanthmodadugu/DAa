package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;

public class FTPDownloader {
	boolean result=false;
	public boolean downloadFiles(String server, String user, String password,String remoteFile1, String downloadFileloc) throws SocketException, IOException{
		FTPClient ftpclient=new FTPClient();
		ftpclient.connect(server);
		ftpclient.login(user, password);
		ftpclient.enterLocalPassiveMode();
		ftpclient.setFileType(FTP.BINARY_FILE_TYPE);
		//String remoteFile1 = "/outbound/dss/sent/NRS_YieldManagementParametersResponse_VT_20180430_1555_00000956.xml";
        File downloadFile1 = new File(downloadFileloc);
       
        OutputStream outputStream2 = new BufferedOutputStream(new FileOutputStream(downloadFile1));
        InputStream inputStream = ftpclient.retrieveFileStream(remoteFile1);
        byte[] bytesArray = new byte[1024];
        int bytesRead = -1;
        while ((bytesRead = inputStream.read(bytesArray)) != -1) {
            outputStream2.write(bytesArray, 0, bytesRead);
        }

       boolean success = ftpclient.completePendingCommand();
        if (success) {
            System.out.println("File # has been downloaded successfully.");
            result=true;
        }
        outputStream2.close();
        inputStream.close();

			
			
		
	return result;	
	}

	

}
