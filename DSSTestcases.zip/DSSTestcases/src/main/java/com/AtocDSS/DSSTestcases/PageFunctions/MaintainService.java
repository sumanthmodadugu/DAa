package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MaintainService {
	WebDriver driver;
	 public MaintainService(WebDriver ldriver) {
		this.driver=ldriver;
	}
	
	@FindBy(xpath="//input[@value='Nested Model']")
	public WebElement nested_model;
	@FindBy(xpath="//input[@value='Booking Controls']")
	public WebElement Booking_Controls;
	@FindBy(xpath="//input[@value='Barred Limited Journeys']")
	public WebElement  Barred_Limited_Journeys;
	
	public ServiceNestedModel navigate_to_nestedmodel(){
		nested_model.click();
		return PageFactory.initElements(driver, ServiceNestedModel.class);
	}

  public void Booking_Controls(){
	  Booking_Controls.click();
  }

  public void Barred_Limited_Journeys(){
	  Barred_Limited_Journeys.click();
	  
  }
  


}
