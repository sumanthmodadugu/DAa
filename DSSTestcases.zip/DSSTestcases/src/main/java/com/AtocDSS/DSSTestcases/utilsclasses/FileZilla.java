package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;

import javax.imageio.ImageIO;

import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class FileZilla {
	
	public void OpenFilezilla(String Host, String User, String Passwd, String Port,String FilePath, String Screenshotpath) throws Exception{
		App filezilla=App.open("C:\\Program Files (x86)\\FileZilla FTP Client\\filezilla.exe");
		Region appRegion = App.focusedWindow();
		Screen screen=new Screen();
		Pattern FZHost=new Pattern("D:\\apache\\FZHostName.PNG");
		Pattern FZUser=new Pattern("D:\\apache\\FZUserName.PNG");
		Pattern FZPasswd=new Pattern("D:\\apache\\FZPassword.PNG");
		Pattern FZPort=new Pattern("D:\\apache\\FZPort.PNG");
		Pattern FZQuickconnect=new Pattern("D:\\apache\\FZQuickconnect.PNG");
		Pattern FZsuccess=new Pattern("D:\\apache\\FZSuccessmsg.PNG");
		Pattern FZaddressbar=new Pattern("D:\\apache\\FZAddressbar.PNG");
		Pattern FZfinalresponse=new Pattern("D:\\apache\\FZfinalresponse.PNG");
		Pattern FZMinimize=new Pattern("D:\\apache\\FZMinimize.PNG");
		
		screen.type(FZHost,Host);
		screen.type(Key.TAB);
		screen.type(User);
		screen.type(Key.TAB);
		screen.type(Passwd);
		screen.type(Key.TAB);
		screen.type(Port);
		screen.type(Key.TAB);
		screen.type(Key.ENTER);
		screen.wait(FZsuccess,120);
		screen.type(Key.BACKSPACE);
		screen.type(FZaddressbar,FilePath);
		screen.type(Key.ENTER);
		Thread.sleep(5000);
		ImageIO.write(screen.capture(appRegion).getImage(), "png", new File(Screenshotpath));
		screen.click(FZMinimize);
		
	}

	

}
