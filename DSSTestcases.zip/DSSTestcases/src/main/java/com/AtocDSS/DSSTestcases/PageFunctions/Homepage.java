package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Homepage {
	WebDriver driver;
	public Homepage(WebDriver ldriver){
		this.driver=ldriver;
		
	}
	@FindBy(xpath="//a[text()='Home']")
	public WebElement Common_Home_Link;
	@FindBy(linkText="Maintain Location Zones")
	public WebElement maintain_location_zone_link;
	@FindBy(linkText="Maintain Specific Service")
	public WebElement maintain_specific_service;
	@FindBy(linkText="Maintain and Configure Product Groups")
	public WebElement Maintain_and_Configure_Product_Groups;
	@FindBy(linkText="Maintain Yield Group Maps")
	public WebElement Maintain_Yield_Group_Map;	
	
	public MaintainLocationzone navigatetolink(){
			maintain_location_zone_link.click();
		return PageFactory.initElements(driver, MaintainLocationzone.class);
			}
	
	public MaintainSpecificService navigate_to_maintain_specificservice(){
		maintain_specific_service.click();
		return PageFactory.initElements(driver, MaintainSpecificService.class);
	}

	public   MaintainProductGroupsFindProductGroups Navigate_to_Maintain_and_Configure_ProductGroups(){

		Maintain_and_Configure_Product_Groups.click();
		return PageFactory.initElements(driver, MaintainProductGroupsFindProductGroups.class);
	}
	
	public MaintainYieldGroupMaps navigate_To_Maintain_Yield_GroupMaps(){
		Common_Home_Link.click();
		Maintain_Yield_Group_Map.click();
		return PageFactory.initElements(driver, MaintainYieldGroupMaps.class);
	}
	
	public MaintainYieldGroupMaps navigate_To_Maintain_Yield_Check_Result(){
		
		Maintain_Yield_Group_Map.click();
		return PageFactory.initElements(driver, MaintainYieldGroupMaps.class);
	}
}


