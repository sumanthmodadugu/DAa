package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

public class FileValidation {

	public boolean validateFile(String XML, String XSD) throws SAXException, IOException{
		SchemaFactory factory=SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema=factory.newSchema(new File(XSD));
		javax.xml.validation.Validator validator=schema.newValidator();
		validator.validate(new StreamSource(new File(XML)));
		
		return true;
		
	}
	

}
