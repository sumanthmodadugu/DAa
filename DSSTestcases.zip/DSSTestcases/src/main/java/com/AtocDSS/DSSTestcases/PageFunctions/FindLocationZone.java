package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.AtocDSS.DSSTestcases.utilsclasses.ReadingPropertiesfile;

public class FindLocationZone {
	WebDriver driver;
	
	public FindLocationZone(WebDriver ldriver){
		this.driver=ldriver;
	}
	
	
	
	public EditLocationZone clickonlocationzone() throws Exception{
		driver.findElement(By.linkText(ReadingPropertiesfile.readcontent("ZoneName","./AllTestDataFile/UC95_LocationZoneUpdate.properties"))).click();
		return PageFactory.initElements(driver, EditLocationZone.class);
	}

}
