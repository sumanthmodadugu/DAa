package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MaintainSpecificService {
	WebDriver driver;
	 public MaintainSpecificService(WebDriver ldriver) {
		this.driver=ldriver;
	}
	
	@FindBy(name="rsid")
	public WebElement rsid_txt_field;
	@FindBy(name="datePeriodFrom")
	public WebElement date_period_from;
	@FindBy(name="datePeriodTo")
	public WebElement date_period_to;
	@FindBy(xpath="//input[@value='All Days']")
	public WebElement all_day_button;
	@FindBy(xpath="//input[@onclick='return checkRunDays();']")
	public WebElement search_button;
	
	public MaintainService navigate_to_maintain_service(String rsid, String startdate){
		rsid_txt_field.sendKeys(rsid);
		date_period_from.sendKeys(startdate);
		all_day_button.click();
		search_button.click();
		
		return PageFactory.initElements(driver, MaintainService.class);
		
	}

}
