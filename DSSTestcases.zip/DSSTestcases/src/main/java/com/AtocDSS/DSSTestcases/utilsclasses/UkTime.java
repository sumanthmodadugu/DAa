package com.AtocDSS.DSSTestcases.utilsclasses;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class UkTime {

	public String uktime(String Format){
		Date day=new Date();

		SimpleDateFormat gmtFormat = new SimpleDateFormat(Format);
		gmtFormat.setTimeZone(TimeZone.getTimeZone("GMT+1") );

		String fmtDay = gmtFormat.format(day);
		System.out.println("fmtDay: " + fmtDay);
		return fmtDay;
	}
	
	
	

}
