package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ErrorPresent {
	
	   int count=0;
	    String lineNumber = "";
	    String filePath = "D:\\Resultxml.txt";
	    BufferedReader br;
	    String inputSearch = "<E";
	    String line = "";
	    public int errorpresent() throws Exception{

	   
	        br = new BufferedReader(new FileReader(filePath));
	        
	            while((line = br.readLine()) != null)
	            {
	            	
	                System.out.println(line);
	                if(line.contains(inputSearch)){
	               count++;
	                break;
	                }
	                
	            }
	     br.close();
	                     	
return count;
	    }        

	    }

