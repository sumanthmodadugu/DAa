package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MaintainLocationzone {
	WebDriver driver;
	
	public MaintainLocationzone(WebDriver ldriver){
		this.driver=ldriver;
	}
	
	@FindBy(name="zoneName")
	public WebElement zonename;
	@FindBy(xpath="//input[@value='Search']")
	public WebElement searchbutton;
	
 public FindLocationZone Searchlocation(String ZoneName){
	 zonename.sendKeys(ZoneName);
	 searchbutton.click();
	 
	 
	return PageFactory.initElements(driver, FindLocationZone.class);
 }
}
