package com.AtocDSS.DSSTestcases.UC95;

import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.AtocDSS.DSSTestcases.PageFunctions.EditLocationZone;
import com.AtocDSS.DSSTestcases.PageFunctions.FindLocationZone;
import com.AtocDSS.DSSTestcases.PageFunctions.LoginPageObjects;
import com.AtocDSS.DSSTestcases.PageFunctions.MaintainLocationzone;
import com.AtocDSS.DSSTestcases.utilsclasses.FTPDownloader;
import com.AtocDSS.DSSTestcases.utilsclasses.FTPUploader;
import com.AtocDSS.DSSTestcases.utilsclasses.FileValidation;
import com.AtocDSS.DSSTestcases.utilsclasses.FileZilla;
import com.AtocDSS.DSSTestcases.utilsclasses.FilecheckfromRemote;
import com.AtocDSS.DSSTestcases.utilsclasses.PuttyLaunching;
import com.AtocDSS.DSSTestcases.utilsclasses.ReadingPropertiesfile;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.Telnetconnection;
import com.AtocDSS.DSSTestcases.utilsclasses.UkTime;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;

public class CommonUtils {
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	WebDriver driver;
	LoginPageObjects login;
	MaintainLocationzone Locationzonepage;
	FindLocationZone findlocationzone;
	EditLocationZone editlocationzone;
	Telnetconnection telnet=new Telnetconnection();
	FTPUploader upld=new FTPUploader();
	FileZilla fz=new FileZilla();
	PuttyLaunching putty=new PuttyLaunching();
	UkTime tm=new UkTime();
	String UKTIME;
	FTPDownloader dn=new FTPDownloader();
	FileValidation fl=new FileValidation();
	FilecheckfromRemote fc=new FilecheckfromRemote();
	
	SoftAssertions sa=new SoftAssertions();
	
	Scenario scenario;
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}

	@And("^To find last sequence number used$")
	public void To_find_last_sequence_number_used() throws Throwable {
		
		telnet.TandemOperationSQLCI("LOGON T.MANAGER", "DBAKEN", "V TBAT",
				ReadingPropertiesfile.readcontent("command","./AllTestDataFile/"+scenario.getName()+".properties"),
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/To find last sequence number used.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/To find last sequence number used.png","To find last sequence number used" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
		  
	}

	@And("^Upload the XML file to App server /inbound/dss/in$")
	public void Upload_the_XML_file_to_App_server_inbound_dss_in() throws Throwable {
		upld.ftpMethod(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("FTPUserName","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("FTPPassword","./AllTestDataFile/"+scenario.getName()+".properties"));
		upld.uploadFile(System.getProperty("user.dir")+"/IOFiles/"+ReadingPropertiesfile.readcontent("InputFileName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("InputFileName","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("Inboundin","./AllTestDataFile/"+scenario.getName()+".properties"));
		
		fz.OpenFilezilla(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("LinuxPort","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("LinuxInboundin","./AllTestDataFile/"+scenario.getName()+".properties"),
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Upload the XML file to App server.png");
		Assert.assertTrue(upld.ifFileExist(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("Inboundin","./AllTestDataFile/"+scenario.getName()+".properties")
				+ReadingPropertiesfile.readcontent("InputFileName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPPassword","./AllTestDataFile/"+scenario.getName()+".properties")));
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Upload the XML file to App server.png","Upload the XML file to App server /inbound/dss/in" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
		
	}

	@And("^Logon to the Tandem Check status of PUB(\\d+).$")
	public void Logon_to_the_Tandem_Check_status_of_PUB_(int arg1) throws Throwable {
		telnet.TandemOperationNormal("LOGON T.MANAGER", "DBAKEN", "V TBAT", "STATUS $T747",
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to the Tandem Check status of PUB.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to the Tandem Check status of PUB.png","Logon to the Tandem Check status of PUB" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	
	}

	@And("^run runBatchDSSin.sh$")
	public void run_runBatchDSSin_sh() throws Throwable {
		putty.puttylaunchingmethod(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
			 ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"), 
			 ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
			 ReadingPropertiesfile.readcontent("BinLocation","./AllTestDataFile/"+scenario.getName()+".properties"),
			 "./runBatchDSSin.sh", 
			 System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/run runBatchDSSin.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/run runBatchDSSin.png","run runBatchDSSin.sh" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	    
	}

	@And("^Check the /inbound/dss/received folder$")
	public void Check_the_inbound_dss_received_folder() throws Throwable {
		
	    fz.OpenFilezilla(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
	    		ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"), 
	    		ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
	    		ReadingPropertiesfile.readcontent("LinuxPort","./AllTestDataFile/"+scenario.getName()+".properties"),
	    		ReadingPropertiesfile.readcontent("LinuxInboundreceived","./AllTestDataFile/"+scenario.getName()+".properties"),
	    		System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check file in received folder.png");	
	    Assert.assertTrue(upld.ifFileExist(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("Inboundreceived","./AllTestDataFile/"+scenario.getName()+".properties")
				+ReadingPropertiesfile.readcontent("InputFileName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPPassword","./AllTestDataFile/"+scenario.getName()+".properties")));
	    ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check file in received folder.png","Check the /inbound/dss/received folder" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	}

	@And("^Check the file in /outbound/dss/in folder$")
	public void Check_the_file_in_outbound_dss_in_folder() throws Throwable {
		
		fz.OpenFilezilla(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPort","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxOutboundin","./AllTestDataFile/"+scenario.getName()+".properties"),
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check file in outbound_in folder.png");
		Assert.assertTrue(upld.ifFileExist(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("Outboundin","./AllTestDataFile/"+scenario.getName()+".properties")
				+ReadingPropertiesfile.readcontent("OutputFileName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPPassword","./AllTestDataFile/"+scenario.getName()+".properties")));
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check file in outbound_in folder.png","Check the file in /outbound/dss/in folder" );
	   // ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	}

	@And("^run runDSSBatch.sh$")
	public void run_runDSSBatch_sh() throws Throwable {
		
		Thread.sleep(60000);
		putty.puttylaunchingmethod(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("BinLocation","./AllTestDataFile/"+scenario.getName()+".properties"), 
				"./runDSSBatch.sh", 
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/run runDSSBatch.png");
		UKTIME=tm.uktime("yyyyMMdd_HHmm");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/run runDSSBatch.png","run runDSSBatch" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	}

	@And("^Check the file in sent folder$")
	public void Check_the_file_in_sent_folder() throws Throwable {
		
		fz.OpenFilezilla(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPort","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxOutboundsent","./AllTestDataFile/"+scenario.getName()+".properties"),
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check file in outbound_sent folder.png");
		Assert.assertTrue(upld.ifFileExist(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("Outboundsent","./AllTestDataFile/"+scenario.getName()+".properties")
				+ReadingPropertiesfile.readcontent("ResponseFile1","./AllTestDataFile/"+scenario.getName()+".properties")+UKTIME+
				ReadingPropertiesfile.readcontent("ResponseFile2","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPPassword","./AllTestDataFile/"+scenario.getName()+".properties")));
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check file in outbound_sent folder.png",
				"Check the file in /outbound/dss/in folde" );
	    
	}

	@And("^Check the logs$")
	public void Check_the_logs() throws Throwable {
		String date=tm.uktime("yyyy-MM-dd");
		putty.puttylaunchingmethod(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LogsLocation","./AllTestDataFile/"+scenario.getName()+".properties"),
				"cat runDSSBatch.sh."+date+".log", 
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/runDSSBatch.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/runDSSBatch.png","runDSSBatch" );
		putty.puttylaunchingmethod(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"), 
				ReadingPropertiesfile.readcontent("LinuxUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LinuxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("LogsLocation","./AllTestDataFile/"+scenario.getName()+".properties"),
				"cat runBatchDSSin.sh."+date+".log", 
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/runBatchDSSin.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/runBatchDSSin.png","runBatchDSSin" );
	}

	@And("^Download the xml file$")
	public void Download_the_xml_file() throws Throwable {
		if(dn.downloadFiles(ReadingPropertiesfile.readcontent("LinuxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FTPPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("Outboundsent","./AllTestDataFile/"+scenario.getName()+".properties")+
				ReadingPropertiesfile.readcontent("ResponseFile1","./AllTestDataFile/"+scenario.getName()+".properties")+UKTIME+
				ReadingPropertiesfile.readcontent("ResponseFile2","./AllTestDataFile/"+scenario.getName()+".properties"),
				System.getProperty("user.dir")+"/IOFiles/"+ReadingPropertiesfile.readcontent("ResponseFile1","./AllTestDataFile/"+scenario.getName()+".properties")+UKTIME+
				ReadingPropertiesfile.readcontent("ResponseFile2","./AllTestDataFile/"+scenario.getName()+".properties")))
			 ws.inserttext("File Downloaded successfullyon"+System.getProperty("user.dir")+"/IOFiles/", "Download the xml file");
		
	}

	@And("^Validate the file$")
	public void Validate_the_file() throws Throwable {
		if(fl.validateFile(System.getProperty("user.dir")+"/IOFiles/"+ReadingPropertiesfile.readcontent("ResponseFile1","./AllTestDataFile/"+scenario.getName()+".properties")+UKTIME+
				ReadingPropertiesfile.readcontent("ResponseFile2","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("XsdLocation","./AllTestDataFile/"+scenario.getName()+".properties")))
			ws.inserttext("File Validated successfully", "Validate the file");
	}

	@And("^Check the file in fax server$")
	public void Check_the_file_in_fax_server() throws Throwable {
		fc.checkPresent(ReadingPropertiesfile.readcontent("FaxServer","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FaxUserName","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FaxPassword","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("FaxLocation","./AllTestDataFile/"+scenario.getName()+".properties"),
				ReadingPropertiesfile.readcontent("ResponseFile1","./AllTestDataFile/"+scenario.getName()+".properties")+UKTIME+
				ReadingPropertiesfile.readcontent("ResponseFile2","./AllTestDataFile/"+scenario.getName()+".properties")+".gz",
				System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check the file in fax server.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check the file in fax server.png","Check the file in fax server" );
	
	}


}
