package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;

import javax.imageio.ImageIO;

import org.apache.poi.hssf.record.CalcModeRecord;
import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class Telnetconnection {
    public App putty;
    
    public void TandemOperationSQLCI(String ENV, String Password, String BATENV, String COMMAND, String Scrnshotloc) throws Exception{
    	
    	putty=App.open("C:\\Program Files\\PuTTY\\PuTTY.exe");
    	Region appRegion = App.focusedWindow();
    	Screen screen=new Screen();
    	Pattern telnet=new Pattern("D:\\apache\\Telnet.PNG");
    	Pattern puttyopen=new Pattern("D:\\apache\\PuttyOpen.PNG");
    	Pattern hostname=new Pattern("D:\\apache\\PuttyHostName.PNG");
    	Pattern TypeTacl=new Pattern("D:\\apache\\EnterChoiceTelnet.PNG");
    	Pattern TypeCMD=new Pattern("D:\\apache\\CMDlineTelnet.PNG");
    	Pattern TBAT=new Pattern("D:\\apache\\RUNJOBTelnet.PNG");
    	Pattern sqlci=new Pattern("D:\\apache\\sqlci.PNG");
    	Pattern puttymaximize=new Pattern("D:\\apache\\PuttyMaximise.PNG");
    	Pattern minimize=new Pattern("D:\\apache\\MinimizePutty.PNG");
    	
    	screen.click(telnet);
    	screen.type(hostname,"172.23.72.26");
    	screen.click(puttyopen);
    	screen.click(puttymaximize);
    	screen.type(TypeTacl,"TACL");
    	screen.type(Key.ENTER);
    	screen.type(ENV);
    	screen.type(Key.ENTER);
    	screen.type(Password);
    	screen.type(Key.ENTER);
    	screen.wait(TypeCMD,60);
    	screen.type(TypeCMD,BATENV);
    	screen.type(Key.ENTER);
    	screen.type(TBAT,"sqlci");
    	screen.type(Key.ENTER);
    	screen.type(COMMAND);
    	screen.type(Key.ENTER);    	
    	screen.wait(sqlci,120);    	
    	
    	ImageIO.write(screen.capture(appRegion).getImage(), "png", new File(Scrnshotloc));
    	
    	screen.click(minimize);
    	
    	
    	
    	
    }
    public void TandemOperationNormal(String ENV, String Password, String BATENV, String COMMAND, String Scrshotloc) throws Exception{
    	putty=App.open("C:\\Program Files\\PuTTY\\PuTTY.exe");
    	Region appRegion = App.focusedWindow();
    	Screen screen=new Screen();
    	Pattern telnet=new Pattern("D:\\apache\\Telnet.PNG");
    	Pattern puttyopen=new Pattern("D:\\apache\\PuttyOpen.PNG");
    	Pattern hostname=new Pattern("D:\\apache\\PuttyHostName.PNG");
    	Pattern TypeTacl=new Pattern("D:\\apache\\EnterChoiceTelnet.PNG");
    	Pattern TypeCMD=new Pattern("D:\\apache\\CMDlineTelnet.PNG");
    	Pattern TBAT=new Pattern("D:\\apache\\RUNJOBTelnet.PNG");
    	//Pattern sqlci=new Pattern("D:\\apache\\sqlci.PNG");
    	Pattern puttymaximize=new Pattern("D:\\apache\\PuttyMaximise.PNG");
    	Pattern minimize=new Pattern("D:\\apache\\MinimizePutty.PNG");
    	
    	screen.click(telnet);
    	screen.type(hostname,"172.23.72.26");
    	screen.click(puttyopen);
    	screen.click(puttymaximize);
    	screen.type(TypeTacl,"TACL");
    	screen.type(Key.ENTER);
    	screen.type(ENV);
    	screen.type(Key.ENTER);
    	screen.type(Password);
    	screen.type(Key.ENTER);
    	screen.wait(TypeCMD,60);
    	screen.type(TypeCMD,BATENV);
    	screen.type(Key.ENTER);
    	screen.type(COMMAND);
    	screen.type(Key.ENTER);
    	screen.wait(TBAT,120);
    	
    	
    	ImageIO.write(screen.capture(appRegion).getImage(), "png", new File(Scrshotloc));
    	
    	screen.click(minimize);
    	
    	
    }
	

}
