package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.SocketException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

public class FTPUploader {
	FTPClient ftp=null;
	public void ftpMethod(String host, String user, String Password) throws Exception{
		ftp=new FTPClient();
		ftp.addProtocolCommandListener(new PrintCommandListener(new PrintWriter(System.out)));
		int reply;
		ftp.connect(host);
		reply=ftp.getReplyCode();
		if(!FTPReply.isPositiveCompletion(reply)){
			ftp.disconnect();
			throw new Exception("Exception in connecting to FTP Server");
			
		}
		ftp.login(user, Password);
		ftp.setFileType(FTP.BINARY_FILE_TYPE);
		ftp.enterLocalPassiveMode();
	}
	
	public void uploadFile(String localFileFullName, String fileName, String hostDir)
			throws Exception {
		try(InputStream input = new FileInputStream(new File(localFileFullName))){
		this.ftp.storeFile(hostDir + fileName, input);
		}
	}
	
	public void disconnect(){
		if (this.ftp.isConnected()) {
			try {
				this.ftp.logout();
				this.ftp.disconnect();
			} catch (IOException f) {
				
			}
		}
	}
	
	public boolean ifFileExist(String host,String FilePathwithname,String user, String Passwd) throws IOException{
		ftp.connect(host);
		ftp.login(user, Passwd);
		InputStream inputstream=ftp.retrieveFileStream(FilePathwithname);
		if (inputstream == null || ftp.getReplyCode() == 550) {
	        return false;
	    }
		return true;
		
	}
	
	public void fileContent(String host,String FilePath,String user, String Passwd) throws IOException{
		ftp.connect(host);
		ftp.login(user, Passwd);
		InputStream in = ftp.retrieveFileStream(FilePath);
		BufferedInputStream bin=new BufferedInputStream(in);
		int bytesRead;
		 byte[] buffer=new byte[1024]; 
		 String filelines=null; 
		 while((bytesRead=bin.read(buffer))!=-1)
		   {
		       filelines=new String(buffer,0,bytesRead); 
		       
		       }
		 System.out.println(filelines);
    }
	
	public void allFilesList(String FilePath, String server, String user, String Password) throws SocketException, IOException{
		ftp.connect(server);
		ftp.enterLocalPassiveMode();
		ftp.login(user, Password);
		
		FTPFile[] files=ftp.listFiles(FilePath);
		DateFormat dateFormater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for(FTPFile file:files){
			String details=file.getName();
			if(file.isDirectory()){
				details="["+details+"]";
				
			}
			details=details+"\t\t"+file.getSize();
			details=details+"\t\t"+dateFormater.format(file.getTimestamp().getTime());
			System.out.println(details);
		}
		
		
	}
	
	

}
