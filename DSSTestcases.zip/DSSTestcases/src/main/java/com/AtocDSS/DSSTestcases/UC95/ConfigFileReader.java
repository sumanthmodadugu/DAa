package com.AtocDSS.DSSTestcases.UC95;

import java.util.Properties;

import com.AtocDSS.DSSTestcases.utilsclasses.ReadingPropertiesfile;

public class ConfigFileReader {
	Properties properties=new Properties();
	public String getReportConfigPath() throws Exception{
		String reportConfigPath = ReadingPropertiesfile.readcontent("reportConfigPath","./Config/Configuration.properties");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}

}
