package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ErrorAndConfirmationtext {
	WebDriver driver;
	public ErrorAndConfirmationtext(WebDriver ldriver) {
		this.driver=ldriver;
	}
	
	
}
