package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class ServiceNestedModel {
	WebDriver driver;
	public ServiceNestedModel(WebDriver ldriver) {
		this.driver=ldriver;
		
	}
	public AssignNestedModeltoRSS navigate_to_RSS(String station){
		driver.findElement(By.linkText(station)).click();;
		return PageFactory.initElements(driver, AssignNestedModeltoRSS.class);
	}

}
