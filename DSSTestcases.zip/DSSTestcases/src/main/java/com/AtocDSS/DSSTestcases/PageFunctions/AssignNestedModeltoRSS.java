package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class AssignNestedModeltoRSS {
	WebDriver driver;
	public AssignNestedModeltoRSS(WebDriver ldriver) {
		this.driver=ldriver;
		
	}
	
	public Allocations navigate_to_allocation(String Accomgrp){
		driver.findElement(By.linkText(Accomgrp)).click();
	return PageFactory.initElements(driver, Allocations.class);	
	}

}
