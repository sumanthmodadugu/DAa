package com.AtocDSS.DSSTestcases.utilsclasses;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

import cucumber.api.Scenario;


public class Hooks {
	
	Scenario scenario;
  public Hooks(Scenario lscenario) {
	  this.scenario=lscenario;
	
}
	
	

	public void afterScenario() throws Exception {
	
		if (scenario.isFailed()) {
			Robot robot=new Robot();
			String screenshotName =  scenario.getName();
			Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
			BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
			ImageIO.write(screenFullImage, "png", new File(System.getProperty("user.dir")+"/FailedReport/"+screenshotName+".png"));
			} 
		}
	}
	
	
	
 

