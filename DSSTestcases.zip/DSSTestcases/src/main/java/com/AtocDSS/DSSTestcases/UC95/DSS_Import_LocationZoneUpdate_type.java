package com.AtocDSS.DSSTestcases.UC95;

import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.AtocDSS.DSSTestcases.PageFunctions.BrowserOperation;
import com.AtocDSS.DSSTestcases.PageFunctions.EditLocationZone;
import com.AtocDSS.DSSTestcases.PageFunctions.ErrorAndConfirmationtext;
import com.AtocDSS.DSSTestcases.PageFunctions.FindLocationZone;
import com.AtocDSS.DSSTestcases.PageFunctions.Homepage;
import com.AtocDSS.DSSTestcases.PageFunctions.LoginPageObjects;
import com.AtocDSS.DSSTestcases.PageFunctions.MaintainLocationzone;
import com.AtocDSS.DSSTestcases.utilsclasses.FTPDownloader;
import com.AtocDSS.DSSTestcases.utilsclasses.FTPUploader;
import com.AtocDSS.DSSTestcases.utilsclasses.FileValidation;
import com.AtocDSS.DSSTestcases.utilsclasses.FileZilla;
import com.AtocDSS.DSSTestcases.utilsclasses.FilecheckfromRemote;
import com.AtocDSS.DSSTestcases.utilsclasses.Hooks;
import com.AtocDSS.DSSTestcases.utilsclasses.PuttyLaunching;
import com.AtocDSS.DSSTestcases.utilsclasses.ReadingPropertiesfile;
import com.AtocDSS.DSSTestcases.utilsclasses.Takescreenshots;
import com.AtocDSS.DSSTestcases.utilsclasses.Telnetconnection;
import com.AtocDSS.DSSTestcases.utilsclasses.UkTime;
import com.AtocDSS.DSSTestcases.utilsclasses.WordScreenshot;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class  DSS_Import_LocationZoneUpdate_type {
	WordScreenshot ws=new WordScreenshot();
	Takescreenshots screen=new Takescreenshots();
	WebDriver driver;
	LoginPageObjects login;
	MaintainLocationzone Locationzonepage;
	FindLocationZone findlocationzone;
	EditLocationZone editlocationzone;
	Telnetconnection telnet=new Telnetconnection();
	FTPUploader upld=new FTPUploader();
	FileZilla fz=new FileZilla();
	PuttyLaunching putty=new PuttyLaunching();
	UkTime tm=new UkTime();
	String UKTIME;
	FTPDownloader dn=new FTPDownloader();
	FileValidation fl=new FileValidation();
	FilecheckfromRemote fc=new FilecheckfromRemote();
	
	SoftAssertions sa=new SoftAssertions();
	
	Scenario scenario;
	@Before
	public void before(Scenario scenario) {
	    this.scenario = scenario;
	}
	@After
	public void printonword() throws Exception{
		Hooks hook=new Hooks(scenario);
		hook.afterScenario();
		ws.insertPic(System.getProperty("user.dir")+"/FailedReport/"+scenario.getName()+".png","Scenario Failed in This step" );
		ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
		
	}
	@Given("^Logon to NRS and navigate to Maintain Location Zones.$")
	public void Logon_to_NRS_and_navigate_to_Maintain_Location_Zones() throws Throwable {
		driver=BrowserOperation.launchApplication(ReadingPropertiesfile.readcontent("URL","./AllTestDataFile/"+scenario.getName()+".properties"));
		login=PageFactory.initElements(driver, LoginPageObjects.class);
		login.verifylogin(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties"), ReadingPropertiesfile.readcontent("Password","./AllTestDataFile/"+scenario.getName()+".properties"));
		if(!login.locationPresent(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties")))
				login.selectlocation();
		
		Homepage Home=PageFactory.initElements(driver, Homepage.class);
		Locationzonepage=Home.navigatetolink();
		screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to NRS and navigate to Maintain Location Zones.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Logon to NRS and navigate to Maintain Location Zones.png","Logon to NRS and navigate to Maintain Location Zones." );
	   // ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
		
	}

	@When("^Enquire on Super Zone - Pre-DSS Update.$")
	public void Enquire_on_Super_Zone_Pre_DSS_Update() throws Throwable {
		findlocationzone=Locationzonepage.Searchlocation(ReadingPropertiesfile.readcontent("ZoneName","./AllTestDataFile/"+scenario.getName()+".properties"));
	    Assert.assertFalse(login.errorTextPresent());
		editlocationzone=findlocationzone.clickonlocationzone();
		screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Enquire on Super Zone - Pre-DSS Update.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Enquire on Super Zone - Pre-DSS Update.png","Enquire on Super Zone - Pre-DSS Update" );
	    //ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
		
		driver.close();
		
	}

		@Then("^Check the UI is updated$")
	public void Check_the_UI_is_updated() throws Throwable {
		driver=BrowserOperation.launchApplication(ReadingPropertiesfile.readcontent("URL","./AllTestDataFile/"+scenario.getName()+".properties"));
		login=PageFactory.initElements(driver, LoginPageObjects.class);
		login.verifylogin(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties"), ReadingPropertiesfile.readcontent("Password","./AllTestDataFile/"+scenario.getName()+".properties"));
		if(!login.locationPresent(ReadingPropertiesfile.readcontent("UserName","./AllTestDataFile/"+scenario.getName()+".properties")))
				login.selectlocation();
		
		Homepage Home=PageFactory.initElements(driver, Homepage.class);
		Locationzonepage=Home.navigatetolink();
		findlocationzone=Locationzonepage.Searchlocation(ReadingPropertiesfile.readcontent("ZoneName","./AllTestDataFile/"+scenario.getName()+".properties"));
		editlocationzone=findlocationzone.clickonlocationzone();
		
		screen.screenshot(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check the UI is updated.png");
		ws.insertPic(System.getProperty("user.dir")+"/Screenshots/"+scenario.getName()+"/Check the UI is updated.png","Check the UI is updated" );
		//ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
		Assert.assertTrue("UI not updated", driver.getPageSource().contains("1004"));
		driver.close();
	}
	

}
