package com.AtocDSS.DSSTestcases.utilsclasses;
import java.awt.event.KeyEvent;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import javax.swing.KeyStroke;

import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class Writetofile {
	
	public void writefile(String content) throws Exception{
		
		PrintWriter writer = new PrintWriter("D:\\Resultxml.txt");
        writer.print(content);       
        writer.close();
		
	}

}
