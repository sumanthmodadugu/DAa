package com.AtocDSS.DSSTestcases.utilsclasses;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.junit.runner.RunWith;
import org.sikuli.script.App;
import org.sikuli.script.Env;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

public class RetailSopi {
	public App Sopi;
		 Screen screen=new Screen();
		 Region appRegion = App.focusedWindow();
		 Pattern startbutton=new Pattern("D:\\apache\\StartButtonLocal.PNG");
		 Pattern searchbox=new Pattern("D:\\apache\\SearchBoxLocal.PNG");
		 Pattern xmlchooser=new Pattern("D:\\apache\\RSXMLChooser.PNG");
		 Pattern messagefiledirectory=new Pattern("D:\\apache\\RSBookingreq.PNG");
		 Pattern inputxml=new Pattern("D:\\apache\\RSInputxml.PNG");
		 Pattern NEW_AM_TEST_44=new Pattern("D:\\apache\\NEW_AM_TEST-44.PNG");
		 Pattern RSEnv=new Pattern("D:\\apache\\RSEnv.PNG");
		 Pattern RSSendmsg=new Pattern("D:\\apache\\RSSendmsg.PNG");
		 Pattern RSResponsescreen=new Pattern("D:\\apache\\RSResponsescreen.PNG");
		 Pattern RSclose=new Pattern("D:\\apache\\RSclose.PNG");
		 
		 
		 public void startSOPI() throws Exception{
		 screen.click(startbutton);
		 screen.type(searchbox,"D:\\Users\\sumodadu\\Desktop\\temp 44\\Tandem Refresh Retail SOPI\\retailsopi.bat");
		 }
		 
		 public void xmlChooser() throws Exception{
		 screen.type(Key.ENTER);
		 screen.click(xmlchooser);
		 }
	
		 
		 public void putInputXML(String requestxmlpath) throws Exception{
		
		 screen.click(inputxml);
		 screen.type("a",KeyModifier.KEY_CTRL);
		 screen.type(Key.DELETE);
		 Filereading fr=new Filereading();
		 screen.paste(fr.reading(requestxmlpath));
		 }
		 
		 public void chooseEnv() throws Exception{
		 screen.click(RSEnv);
		 for(int j=0;j<49;j++){
			 
				
			 if(screen.exists(NEW_AM_TEST_44) != null){
				 
			
			 screen.click(NEW_AM_TEST_44);
			 break;
			 }
			 else
				 
				 screen.type(Key.PAGE_DOWN);
			 
			 }
		 }
		 
		 public void finalOutput(String screenshotpath) throws Exception{
		 screen.click(RSSendmsg);
		 screen.click(RSResponsescreen);
		 screen.type("a",KeyModifier.KEY_CTRL);
		screen.type("c",KeyModifier.KEY_CTRL);
		String Total=Env.getClipboard();
		Writetofile wr=new Writetofile();
		wr.writefile(Total);
		ErrorPresent er=new ErrorPresent();
		System.out.println(er.errorpresent());
		ImageIO.write(screen.capture(appRegion).getImage(), "png", new File(screenshotpath));
		screen.click(RSclose);
		
		 } 
		 
		 
		 


	
	
public void select_BookingRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern BookingRequest=new Pattern("D:\\apache\\RSBookingreq.PNG");
	 for(int i=0;i<35;i++){
		 
		
		 if(screen.exists(BookingRequest) != null){
			 
		
		 screen.click(BookingRequest);
		 break;
		 }
		 else
			 
			 screen.type(Key.PAGE_DOWN);
		 
		 }
	}
	
public void select_AvaliblityRequest() throws Exception{ 
	
	Screen screen=new Screen();
 Pattern AvaliblityRequest=new Pattern("D:\\apache\\RSAvailabilityreq.PNG");
 for(int i=0;i<35;i++){
	 
	
	 if(screen.exists(AvaliblityRequest) != null){
		 
	
	 screen.click(AvaliblityRequest);
	 break;
	 }
	 else
		 
		 screen.type(Key.PAGE_DOWN);
	 
	 }
}




public void select_CoachAvailabilityRequest () throws Exception{ 
	
	Screen screen=new Screen();
 Pattern CoachAvailabilityRequest =new Pattern("D:\\apache\\RSCoachAvailabilityreq.PNG");
 for(int i=0;i<35;i++){
	 
	
	 if(screen.exists(CoachAvailabilityRequest ) != null){
		 
	
	 screen.click(CoachAvailabilityRequest );
	 break;
	 }
	 else
		 
		 screen.type(Key.PAGE_DOWN);
	 
	 }
}




public void select_UnrestrictedAvailabilityRequest() throws Exception{ 
	
	Screen screen=new Screen();
 Pattern UnrestrictedAvailabilityRequest  =new Pattern("D:\\apache\\RsUnrestrictedAvailabilityReq.PNG");
 for(int i=0;i<35;i++){
	 
	
	 if(screen.exists(UnrestrictedAvailabilityRequest) != null){
		 
	
	 screen.click(UnrestrictedAvailabilityRequest);
	 break;
	 }
	 else
		 
		 screen.type(Key.PAGE_DOWN);
	 
	 }
}
 
 public void select_UnrestrictedTogetherAvailabilityRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern UnrestrictedTogetherAvailabilityRequest  =new Pattern("D:\\apache\\RsUnrestrictedTogetherAvailabilityReq.PNG");
	 for(int i=0;i<35;i++){
		 
		
		 if(screen.exists(UnrestrictedTogetherAvailabilityRequest) != null){
			 
		
		 screen.click(UnrestrictedTogetherAvailabilityRequest);
		 break;
		 }
		 else
			 
			 screen.type(Key.PAGE_DOWN);
		 
		 }
}
 
 public void select_TogetherAvailabilityRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern TogetherAvailabilityRequest  =new Pattern("D:\\apache\\RsTogetherAvailabilityReq.PNG");
	 for(int i=0;i<35;i++){
		 
		
		 if(screen.exists(TogetherAvailabilityRequest) != null){
			 
		
		 screen.click(TogetherAvailabilityRequest);
		 break;
		 }
		 else
			 
			 screen.type(Key.PAGE_DOWN);
		 
		 }
}
 
 
 

 
 public void select_ProductAvailabilityRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern ProductAvailabilityRequest  =new Pattern("D:\\apache\\RsProductAvailabilityReq.PNG");
	 for(int i=0;i<35;i++){
		 
		
		 if(screen.exists(ProductAvailabilityRequest) != null){
			 
		
		 screen.click(ProductAvailabilityRequest);
		 break;
		 }
		 else
			 
			 screen.type(Key.PAGE_DOWN);
		 
		 }
}
 public void select_SeasonBookingRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern SeasonBookingRequest =new Pattern("D:\\apache\\RsSeasonBookingReq.PNG");
	 for(int i=0;i<5;i++){
		 
			 
			 screen.type(Key.PAGE_DOWN);
		 
		 }
	 screen.click(SeasonBookingRequest);
}
 
 
 public void select_RecallBookingRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern RecallBookingRequest  =new Pattern("D:\\apache\\RsRecallBookingReq.PNG");
	 for(int i=0;i<5;i++){
		 
			 
			 screen.type(Key.PAGE_DOWN);
		 
		 }
	 screen.click(RecallBookingRequest);
}

 
 public void select_CancelBookingRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern CancelBookingRequest   =new Pattern("D:\\apache\\RsCancelBookingReq.PNG");
	 for(int i=0;i<35;i++){
		 
		 if(screen.exists(CancelBookingRequest) != null){	
		 screen.click(CancelBookingRequest);
		 break;
		 }
		 else
			 
			 screen.type(Key.PAGE_DOWN);
		 }
 }
 public void select_CancelGroupBookingRequest() throws Exception{ 
		
		Screen screen=new Screen();
		
	 Pattern CancelGroupBookingRequest   =new Pattern("D:\\apache\\RsCancelGroupBookingReq.PNG");
	 screen.type(Key.PAGE_DOWN);
		 
		
		 screen.type(Key.PAGE_DOWN);			 
			
		 screen.click(CancelGroupBookingRequest);
		 }
 
 
 public void select_GroupBookingRequest() throws Exception{ 
		
		Screen screen=new Screen();
	 Pattern GroupBookingRequest   =new Pattern("D:\\apache\\RsGroupBookingReq.PNG");
	 for(int i=0;i<35;i++){
		 
		 if(screen.exists(GroupBookingRequest) != null){	
		 screen.click(GroupBookingRequest);
		 break;
		 }
		 else
			 
			 screen.type(Key.PAGE_DOWN);
		 }
}
}

 

