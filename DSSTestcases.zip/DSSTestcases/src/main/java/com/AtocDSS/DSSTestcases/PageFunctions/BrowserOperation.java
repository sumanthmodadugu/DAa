/**
 * 
 */
package com.AtocDSS.DSSTestcases.PageFunctions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author suvbaner
 *
 */
public class BrowserOperation {
	public static WebDriver driver;
	public static WebDriver launchApplication(String URL){
		System.setProperty("webdriver.chrome.driver","./RequiredFiles/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		return driver;
	}

}
