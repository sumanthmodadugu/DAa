package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Allocations {
	WebDriver driver;
	public Allocations(WebDriver ldriver) {
		this.driver=ldriver;


	}
	
	@FindBy(xpath="//div[@style='border-left: solid thin black; border-top: solid thin black;']/table/tbody/tr[1]/td[4]/input")
	public WebElement limit;
	
	public String limit(){
		return limit.getAttribute("value");
	}

}
