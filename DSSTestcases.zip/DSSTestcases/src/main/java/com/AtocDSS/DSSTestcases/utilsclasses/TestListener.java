package com.AtocDSS.DSSTestcases.utilsclasses;

import org.junit.Ignore;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

public class TestListener extends RunListener {
	WordScreenshot ws=new WordScreenshot();
	
	 @Override
	    public void testRunStarted(Description description) throws Exception {
	        
	    }
	 
	    @Override
	    public void testRunFinished(Result result) throws Exception {
	    	ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	        
	    }
	 
	    @Override
	    public void testStarted(Description description) throws Exception {
	       
	    }
	 
	    @Override
	    public void testFinished(Description description) throws Exception {
	    	ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	    }
	 
	    @Override
	    public void testFailure(Failure failure) throws Exception {
	    	ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	    }
	 
	    //O.B: IntelliJ ignored by default. I did not succeed to run this method.
	    //If you know any way to accomplish this, please write a comment.
	    @Override
	    public void testIgnored(Description description) throws Exception {
	    	ws.printout(System.getProperty("user.dir")+"/EvidencesDocuments/UC_95DSS_Import_LocationZoneUpdate_type.docx");
	    }
	
	

}
