/**
 * 
 */
package com.AtocDSS.DSSTestcases.PageFunctions;

import org.omg.PortableInterceptor.LOCATION_FORWARD;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



/**
 * @author suvbaner
 *
 */
public class LoginPageObjects {
	WebDriver driver;
	public LoginPageObjects(WebDriver ldriver) {
		this.driver=ldriver;
	}
	@FindBy(xpath="//input[@name='username']")
	public WebElement Enterusername;
	@FindBy(xpath="//input[@name='password']")
	public WebElement EnterPassword;
	@FindBy(xpath="//input[@value='OK']")
	public WebElement OKbutton;
	@FindBy(xpath="//input[@value='Cancel']")
	public WebElement Cancelbutton;
	@FindBy(xpath="//td[@class='errortext']")
	public WebElement ErrorText;
	@FindBy(xpath="//select[@name='location']")
	WebElement Location_Box;
	@FindBy(xpath="//td[@class='confirmationtext']")
	public WebElement CONFIRMATION_TEXT;
	@FindBy(name="confirmPassword")
	public WebElement CONFIRM_PASSWORD_TEXT_FIELD;
	@FindBy(linkText="Logout")
	public WebElement LOGOUT_LINK;
	@FindBy(linkText="Login")
	public WebElement LOGIN_LINK;
	
	
	
	
	public void verifylogin(String user, String Pass){
		LOGIN_LINK.click();     
		Enterusername.clear();
	    Enterusername.sendKeys(user);
	    EnterPassword.sendKeys(Pass);
	    OKbutton.click();
		
	}
	
	public void changePassword(String USER, String PASS, String NEWPASS){
		Enterusername.sendKeys(USER);
		EnterPassword.sendKeys(PASS);
		OKbutton.click();
		if(ErrorText.getText().equals("You are required to change your password!")){
			EnterPassword.sendKeys(NEWPASS);
			CONFIRM_PASSWORD_TEXT_FIELD.sendKeys(NEWPASS);
			OKbutton.click();
		}
	}
	
	public void selectlocation(){
		
	 OKbutton.click();
	}
	
	public boolean locationPresent(String USER){
		boolean x=false;
		if(driver.getPageSource().contains(USER)){
			System.out.println("true");
			x=true;
		}
		return x;
	}
	public boolean errorTextPresent(){
		boolean t=false;
		if(!ErrorText.getText().equals(""))
			t=true;
		return t;
	}
	
	
	
}
