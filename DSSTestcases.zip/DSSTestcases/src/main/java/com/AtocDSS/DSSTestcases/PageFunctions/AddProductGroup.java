package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AddProductGroup {

WebDriver driver;
	
	public AddProductGroup(WebDriver ldriver){
		this.driver=ldriver;
		
	}
	@FindBy(name="pgName")
	WebElement ProductGroupName_TextBox;
	
	@FindBy(name="pgDescription")
	WebElement ProductGrouDescription_TextBox;
	
	@FindBy(name="pgEffectiveFrom")
	WebElement FromDate_TextBox;
	
	@FindBy(name="pgEffectiveTo")
	WebElement ToDate_TextBox;
	
	@FindBy(name="defaultYG")
	WebElement DefaultYieldGroup_DropDown;
	
	@FindBy(xpath="//input[@title='Save Product Group']")
	WebElement Save_Button;
	
	
	
	public  void Navigate_to_Add_Product_Group (String PGroupName, String Description, String EffectiveFrom, String EffectiveTo,String DropDownvalue  ){
		ProductGroupName_TextBox.sendKeys(PGroupName);
		ProductGrouDescription_TextBox.sendKeys(Description);
		FromDate_TextBox.clear();
		FromDate_TextBox.sendKeys(EffectiveFrom);
		ToDate_TextBox.sendKeys(EffectiveTo);		
           Select DropYieldGroup =new Select(DefaultYieldGroup_DropDown);
           DropYieldGroup.selectByVisibleText(DropDownvalue);
          Save_Button.click();
	}
	
}
