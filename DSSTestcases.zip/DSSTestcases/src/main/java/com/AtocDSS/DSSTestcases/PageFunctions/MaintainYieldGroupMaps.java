package com.AtocDSS.DSSTestcases.PageFunctions;

import org.openqa.selenium.WebDriver;

public class MaintainYieldGroupMaps {
WebDriver driver;
	
	public MaintainYieldGroupMaps(WebDriver ldriver){
		this.driver=ldriver;
	}
	
}
