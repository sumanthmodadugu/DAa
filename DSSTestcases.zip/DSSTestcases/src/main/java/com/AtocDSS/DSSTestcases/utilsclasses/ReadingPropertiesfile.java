package com.AtocDSS.DSSTestcases.utilsclasses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class ReadingPropertiesfile {
	
	public static String readcontent(String Property, String Fileloc) throws Exception{
		Properties prop=new Properties();
		FileInputStream FI=new FileInputStream(Fileloc);
		prop.load(FI);
		return prop.getProperty(Property);
	}
	
	
	

}
