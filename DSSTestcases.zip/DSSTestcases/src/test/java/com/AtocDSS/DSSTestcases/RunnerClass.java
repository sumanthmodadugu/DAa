package com.AtocDSS.DSSTestcases;

import java.io.File;
import java.io.FileReader;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.AtocDSS.DSSTestcases.utilsclasses.Manager;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.java.After;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)

@CucumberOptions(features="FeatureFileRetailSopi",glue={"AtocDSSSOPI"}, tags={"@UC104"}, plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html"},
monochrome = true)

//@CucumberOptions(features="FeaturefilesUC95",glue={"com.AtocDSS.DSSTestcases.UC95"}, tags={"@LocationZone"}, plugin = {"pretty" ,"html:FailedReport","json:FailedReport/cucumber.json", "junit:FailedReport/cucumber.xml"},
//monochrome = true)


public class RunnerClass{

	@AfterClass
	public static void writeExtentReport() throws Exception {
		Reporter.loadXMLConfig(new File(Manager.getInstance().getConfigReader().getReportConfigPath()));
	}
 
}